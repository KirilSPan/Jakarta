/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stefanov.pangarov_kiril.jakartaxml;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import java.io.File;

/**
 *
 * @author Kiril_SP
 */
public class AccesoJakarta {

    /**
     * @param args the command line arguments
     * @throws jakarta.xml.bind.JAXBException
     */
    @SuppressWarnings("CallToPrintStackTrace")
    public static void main(String[] args) throws JAXBException {

        try {
            JAXBContext context = JAXBContext.newInstance(Catalog.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            Catalog books = (Catalog) unmarshaller.unmarshal(new File("books.xml"));

            for (Book book : books.getBooks()) {

                System.out.println(book.getId());
                System.out.println(book.getTitle());
                System.out.println(book.getAuthor());
                System.out.println(book.getGenre());
                System.out.println(book.getPrice());
                System.out.println(book.getPublish_date());
                System.out.println(book.getDescription());

            }

        } catch (JAXBException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}
